from django.contrib import admin
from .models import Doctors

admin.site.register(Doctors)

