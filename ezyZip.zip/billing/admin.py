from django.contrib import admin
from .models import Bill

admin.site.register(Bill)

