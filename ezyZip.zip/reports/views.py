from rest_framework import viewsets
from .models import Reports
from .serializers import ReportsSerializer

class ReportsViewSet(viewsets.ModelViewSet):
    queryset = Reports.objects.all()
    serializer_class = ReportsSerializer

