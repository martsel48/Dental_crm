from rest_framework import viewsets
from .models import Inventory_items
from .serializers import Inventory_itemsSerializer

class Inventory_itemsViewSet(viewsets.ModelViewSet):
    queryset = Inventory_items.objects.all()
    serializer_class = Inventory_itemsSerializer

