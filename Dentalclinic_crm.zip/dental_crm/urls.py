"""
URL configuration for dental_crm project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from patients.views import PatientViewSet
from doctors.views import DoctorsViewSet
from staff.views import StaffViewSet
from appointments.views import AppointmentsViewSet
from billing.views import BillingViewSet
from user.views import UserViewSet
from reports.views import ReportsViewSet
from inventory_items.views import Inventory_itemsViewSet
from notifications.views import NotificationsViewSet

router = routers.DefaultRouter()
router.register(r'patients', PatientViewSet)
router.register(r'doctors', DoctorsViewSet)
router.register(r'staff', StaffViewSet)
router.register(r'appointments', AppointmentsViewSet)
router.register(r'billing', BillingViewSet)
router.register(r'user', UserViewSet)
router.register(r'reports', ReportsViewSet)
router.register(r'inventory_items', Inventory_itemsViewSet)
router.register(r'notifications', NotificationsViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
]

