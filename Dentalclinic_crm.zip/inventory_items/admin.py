from django.contrib import admin
from .models import Inventory_items

admin.site.register(Inventory_items)
