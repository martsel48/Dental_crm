from django.contrib import admin
from .models import Staff

admin.site.register(Staff)

