from django.contrib import admin
from .models import Reports

admin.site.register(Reports)
