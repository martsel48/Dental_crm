
from django.db import models
from patients.models import Patient
from doctors.models import Doctors

class User(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctors = models.ForeignKey(Doctors, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    reason = models.TextField()
    status = models.CharField(max_length=20, default="Pending")  # Pending, Completed, Cancelled

    def __str__(self):
        return f"{self.patient.name} with {self.doctors.name} on {self.date}"


