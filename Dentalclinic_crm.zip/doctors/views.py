# from rest_framework import viewsets
# from .models import Doctors
# from .serializers import DoctorsSerializer

# class PatientViewSet(viewsets.ModelViewSet):
#     queryset = Doctors.objects.all()
#     serializer_class = DoctorsSerializer



# doctors/views.py
from rest_framework import viewsets
from .models import Doctors
from .serializers import DoctorsSerializer

class DoctorsViewSet(viewsets.ModelViewSet): 
    queryset = Doctors.objects.all()
    serializer_class = DoctorsSerializer
